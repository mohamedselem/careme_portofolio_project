#CAREME

CAREME is my portofolio project that intends to streamline the healthcare journey for individuals seeking specialist care.
Thereby Bypassing initial hospital visit and records.
